package my_proxy;

public class CircleTest {
	public static void main(String[] args) {
		new Circle(3).area().round().setR(5).area();		
	}
}
